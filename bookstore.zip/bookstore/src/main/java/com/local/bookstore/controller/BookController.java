package com.local.bookstore.controller;

import com.local.bookstore.dto.request.BookRequestDto;
import com.local.bookstore.service.BookService;
import com.local.bookstore.util.CommonResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/books")
@RequiredArgsConstructor
public class BookController {

    private final BookService bookService;

    @PostMapping("/create")
    public ResponseEntity<CommonResponse> createBook(@RequestBody @Valid BookRequestDto bookRequestDto) {
        log.info("BookController.createBook() => started");
        return ResponseEntity.status(HttpStatus.CREATED).body(bookService.createBook(bookRequestDto));
    }

    @PutMapping("/update")
    public ResponseEntity<CommonResponse> updateBook(@RequestBody @Valid BookRequestDto bookRequestDto,
                                                     @RequestParam Long id) {
        log.info("BookController.updateBook() => started");
        return ResponseEntity.status(HttpStatus.OK).body(bookService.updateBook(bookRequestDto, id));
    }

    @GetMapping("/{id}")
    public ResponseEntity<CommonResponse> getBookById(@PathVariable Long id) {
        log.info("BookController.getBookById() => started");
        return ResponseEntity.status(HttpStatus.OK).body(bookService.getBookById(id));
    }

    @GetMapping
    public ResponseEntity<CommonResponse> getBooks() {
        log.info("BookController.getBooks() => started");
        return ResponseEntity.status(HttpStatus.OK).body(bookService.getAllBooks());
    }

    @DeleteMapping
    public ResponseEntity<CommonResponse> deleteBookById(@RequestParam Long id) {
        log.info("BookController.deleteBookById() => started");
        return ResponseEntity.status(HttpStatus.OK).body(bookService.deleteBook(id));
    }


}
