package com.local.bookstore.service.impl;

import com.local.bookstore.dto.request.BookRequestDto;
import com.local.bookstore.dto.response.BookResponseDto;
import com.local.bookstore.entity.Book;
import com.local.bookstore.exception.ResourceNotFoundException;
import com.local.bookstore.mapper.BookMapper;
import com.local.bookstore.repository.BookRepository;
import com.local.bookstore.service.BookService;
import com.local.bookstore.util.CommonResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class BookServiceImpl implements BookService {

    private final BookRepository bookRepository;
    private final BookMapper bookMapper;

    @Override
    public CommonResponse createBook(BookRequestDto bookRequestDto) {
        log.info("BookServiceImpl.createBook => accessed");
        Book book = bookRepository.save(bookMapper.toEntity(bookRequestDto));
        return new CommonResponse(HttpStatus.CREATED, "Book created successfully", bookMapper.toDto(book));
    }

    @Override
    public CommonResponse updateBook(BookRequestDto bookRequestDto, Long id) {
        log.info("BookServiceImpl.updateBook => accessed");
        Book book = bookRepository.findById(Math.toIntExact(id)).orElseThrow(() -> new ResourceNotFoundException("Book not found"));
        book.setTitle(bookRequestDto.getTitle());
        book.setAuthor(bookRequestDto.getAuthor());
        book.setIsbn(bookRequestDto.getIsbn());
        book.setPublicationYear(bookRequestDto.getPublicationYear());
        book.setPrice(bookRequestDto.getPrice());
        Book savedBook = bookRepository.save(book);
        return new CommonResponse(HttpStatus.OK, "Book updated successfully", bookMapper.toDto(savedBook));
    }

    @Override
    public CommonResponse deleteBook(Long id) {
        log.info("BookServiceImpl.deleteBook => accessed");
        Book book = bookRepository.findById(Math.toIntExact(id)).orElseThrow(() -> new ResourceNotFoundException("Book not found"));
        bookRepository.delete(book);
        return new CommonResponse(HttpStatus.OK, "Book deleted successfully", null);
    }

    @Override
    public CommonResponse getAllBooks() {
        log.info("BookServiceImpl.getAllBooks => accessed");
        List<Book> books = bookRepository.findAll();
        if (books.isEmpty()) {
            throw new ResourceNotFoundException("Books not found");
        }
        List<BookResponseDto> bookResponseDto = books.stream().map(bookMapper::toDto).toList();
        return new CommonResponse(HttpStatus.OK, "Books retrieved successfully", bookResponseDto);
    }

    @Override
    public CommonResponse getBookById(Long id) {
        log.info("BookServiceImpl.getBookById => accessed");
        Book book = bookRepository.findById(Math.toIntExact(id)).orElseThrow(() -> new ResourceNotFoundException("Book not found"));
        BookResponseDto bookResponseDto = bookMapper.toDto(book);
        return new CommonResponse(HttpStatus.OK, "Book retrieved successfully", bookResponseDto);
    }
}
