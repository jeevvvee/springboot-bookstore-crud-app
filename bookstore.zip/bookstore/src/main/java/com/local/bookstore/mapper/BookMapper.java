package com.local.bookstore.mapper;

import com.local.bookstore.dto.request.BookRequestDto;
import com.local.bookstore.dto.response.BookResponseDto;
import com.local.bookstore.entity.Book;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class BookMapper {


    public BookResponseDto toDto(Book book) {
        log.info("BookMapper.toDto() => accessed");
        return BookResponseDto.
                builder().bookId(book.getIdBook()).
                title(book.getTitle()).
                author(book.getAuthor()).
                price(book.getPrice()).
                build();

    }

    public Book toEntity(BookRequestDto bookRequestDto) {
        log.info("BookMapper.toEntity() => accessed");
        Book book = new Book();
        book.setTitle(bookRequestDto.getTitle());
        book.setAuthor(bookRequestDto.getAuthor());
        book.setIsbn(bookRequestDto.getIsbn());
        book.setPublicationYear(bookRequestDto.getPublicationYear());
        book.setPrice(bookRequestDto.getPrice());
        return book;
    }
}
