package com.local.bookstore.service;

import com.local.bookstore.dto.request.BookRequestDto;
import com.local.bookstore.util.CommonResponse;

public interface BookService {

    CommonResponse createBook(BookRequestDto bookRequestDto);
    CommonResponse updateBook(BookRequestDto bookRequestDto, Long id);
    CommonResponse deleteBook(Long id);
    CommonResponse getAllBooks();
    CommonResponse getBookById(Long id);
}
