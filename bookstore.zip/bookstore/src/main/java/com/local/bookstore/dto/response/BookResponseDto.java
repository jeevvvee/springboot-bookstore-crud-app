package com.local.bookstore.dto.response;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@Builder
public class BookResponseDto {
    private Long bookId;
    private String title;
    private String author;
    private String isbn;
    private Integer publicationYear;
    private BigDecimal price;

}
